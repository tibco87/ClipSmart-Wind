// ClipSmart Content Script for Firefox

// Listen for messages from background script
browser.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
    try {
        switch (request.action) {
            case 'getClipboardText':
                const clipboardText = await getClipboardText();
                sendResponse({ success: true, text: clipboardText });
                break;
                
            default:
                sendResponse({ success: false, error: 'Unknown action' });
        }
    } catch (error) {
        console.error('Error handling message in content script:', error);
        sendResponse({ success: false, error: error.message });
    }
    
    return true; // Keep message channel open for async response
});

// Get clipboard text
async function getClipboardText() {
    try {
        // Try to get text from clipboard
        const text = await navigator.clipboard.readText();
        return text;
    } catch (error) {
        console.log('Could not read clipboard text:', error);
        return '';
    }
}

// Monitor clipboard changes (if supported)
if (navigator.clipboard && navigator.clipboard.addEventListener) {
    try {
        navigator.clipboard.addEventListener('clipboardchange', async (event) => {
            try {
                const text = await navigator.clipboard.readText();
                if (text && text.trim()) {
                    // Send to background script
                    browser.runtime.sendMessage({
                        action: 'saveClipboardItem',
                        text: text.trim(),
                        source: window.location.href,
                        timestamp: Date.now()
                    });
                }
            } catch (error) {
                console.log('Error reading clipboard on change:', error);
            }
        });
    } catch (error) {
        console.log('Clipboard change monitoring not supported:', error);
    }
}

// Monitor selection changes as fallback
let lastSelection = '';
document.addEventListener('selectionchange', () => {
    const selection = window.getSelection();
    if (selection && selection.toString().trim() !== lastSelection) {
        lastSelection = selection.toString().trim();
        // Don't auto-save selections, just update lastSelection
    }
});

// Add context menu for selected text
document.addEventListener('mouseup', () => {
    const selection = window.getSelection();
    if (selection && selection.toString().trim()) {
        // Selection exists, could show custom context menu here if needed
    }
});

console.log('🚀 ClipSmart Firefox content script loaded');
