// ClipSmart Background Script for Firefox

// ExtensionPay Configuration
const EXTENSION_ID = 'nbpndheaoecmgnlmfpleeahoicpcbppj';
const EXTPAY_CONFIG = {
    extensionId: EXTENSION_ID,
    limits: {
        free: {
            items: 20,
            translationsPerDay: 5,
            exportFormats: ['txt'],
            tags: false
        },
        premium: {
            items: Infinity,
            translationsPerDay: Infinity,
            exportFormats: ['txt', 'csv', 'json'],
            tags: true
        }
    }
};

// Load ExtensionPay script
importScripts('../js/extpay.js');

// ExtensionPay is loaded as a global function

// Initialize extension
browser.runtime.onInstalled.addListener(async (details) => {
    if (details.reason === 'install') {
        // Set default settings on first install
        await browser.storage.local.set({
            clipboardItems: [],
            settings: {
                theme: 'auto',
                language: 'en',
                autoDelete: 'never',
                translationLangs: ['en', 'de', 'fr']
            },
            isPro: false,
            translationsUsed: 0,
            installDate: Date.now()
        });

        // Open welcome page
        browser.tabs.create({ url: browser.runtime.getURL('welcome.html') });
    }

    // Initialize ExtensionPay
    setTimeout(() => {
        if (typeof self.ExtPay !== 'undefined') {
            // Use the production Extension ID from Chrome Web Store
            const extensionPayId = 'nbpndheaoecmgnlmfpleeahoicpcbppj';
            const extpay = self.ExtPay(extensionPayId);
            extpay.startBackground();
            console.log('✅ ExtensionPay initialized in background with ID:', extensionPayId);
        } else {
            console.error('ExtensionPay not available in background');
            console.log('Available globals:', Object.keys(self).filter(key => key.includes('Ext')));
        }
    }, 100);

    // Create context menu
    browser.contextMenus.removeAll(function() {
        browser.contextMenus.create({
            id: 'save-to-clipsmart',
            title: 'Save to ClipSmart',
            contexts: ['selection']
        });
    });

    // Create alarms
    try {
        await browser.alarms.create('resetTranslations', {
            periodInMinutes: 60 * 24 * 30 // Monthly
        });
        
        await browser.alarms.create('cleanup', {
            periodInMinutes: 60 * 24 // Daily
        });

        await browser.alarms.create('checkClipboard', {
            periodInMinutes: 1/60 // Every second
        });
    } catch (error) {
        console.error('Failed to create alarms:', error);
    }
});

// Handle clipboard monitoring
let clipboardMonitor = {
    lastText: '',
    
    async checkClipboard() {
        try {
            // Získaj aktívny tab
            const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
            if (!tab || !tab.id) return;

            // Pošli správu content scriptu, aby prečítal schránku
            try {
                await browser.tabs.sendMessage(tab.id, { action: 'getClipboardText' });
            } catch (error) {
                // Content script nemusí byť dostupný na všetkých stránkach
                console.log('Content script not available on this page');
            }
        } catch (error) {
            console.error('Error checking clipboard:', error);
        }
    }
};

// Handle alarms
browser.alarms.onAlarm.addListener(async (alarm) => {
    switch (alarm.name) {
        case 'resetTranslations':
            await resetMonthlyTranslations();
            break;
        case 'cleanup':
            await cleanupOldItems();
            break;
        case 'checkClipboard':
            clipboardMonitor.checkClipboard();
            break;
    }
});

// Reset monthly translations
async function resetMonthlyTranslations() {
    try {
        const now = new Date();
        const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        
        const { translationsThisMonth } = await browser.storage.local.get('translationsThisMonth');
        
        if (translationsThisMonth && translationsThisMonth.month !== currentMonth) {
            await browser.storage.local.set({
                translationsThisMonth: {
                    month: currentMonth,
                    count: 0
                },
                translationsUsed: 0
            });
            console.log('✅ Monthly translations reset');
        }
    } catch (error) {
        console.error('Error resetting translations:', error);
    }
}

// Cleanup old items
async function cleanupOldItems() {
    try {
        const { clipboardItems, settings } = await browser.storage.local.get(['clipboardItems', 'settings']);
        
        if (settings.autoDelete === 'never' || !clipboardItems.length) return;
        
        const now = Date.now();
        let deletedCount = 0;
        
        // Calculate cutoff time based on autoDelete setting
        let cutoffTime;
        switch (settings.autoDelete) {
            case '1day':
                cutoffTime = now - (24 * 60 * 60 * 1000);
                break;
            case '7days':
                cutoffTime = now - (7 * 24 * 60 * 60 * 1000);
                break;
            case '30days':
                cutoffTime = now - (30 * 24 * 60 * 60 * 1000);
                break;
            default:
                return;
        }
        
        // Filter out old items
        const updatedItems = clipboardItems.filter(item => {
            if (item.timestamp < cutoffTime) {
                deletedCount++;
                return false;
            }
            return true;
        });
        
        if (deletedCount > 0) {
            await browser.storage.local.set({ clipboardItems: updatedItems });
            console.log(`🧹 Cleaned up ${deletedCount} old clipboard items`);
        }
    } catch (error) {
        console.error('Error during cleanup:', error);
    }
}

// Handle messages from popup and content scripts
browser.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
    try {
        switch (request.action) {
            case 'translateText':
                const result = await translateText(request.text, request.targetLang);
                sendResponse({ success: true, translation: result });
                break;
                
            case 'getClipboardItems':
                const { clipboardItems } = await browser.storage.local.get('clipboardItems');
                sendResponse({ success: true, items: clipboardItems || [] });
                break;
                
            case 'saveClipboardItem':
                const { text, source, timestamp } = request;
                const { clipboardItems: existingItems } = await browser.storage.local.get('clipboardItems');
                
                const newItem = {
                    id: Date.now().toString(),
                    text,
                    source: source || 'unknown',
                    timestamp: timestamp || Date.now(),
                    tags: []
                };
                
                const updatedItems = [newItem, ...(existingItems || [])];
                
                // Limit items for free users
                const { isPro } = await browser.storage.local.get('isPro');
                const maxItems = isPro ? Infinity : EXTPAY_CONFIG.limits.free.items;
                
                if (updatedItems.length > maxItems) {
                    updatedItems.splice(maxItems);
                }
                
                await browser.storage.local.set({ clipboardItems: updatedItems });
                sendResponse({ success: true, item: newItem });
                break;
                
            case 'deleteClipboardItem':
                const { itemId } = request;
                const { clipboardItems: currentItems } = await browser.storage.local.get('clipboardItems');
                const filteredItems = currentItems.filter(item => item.id !== itemId);
                await browser.storage.local.set({ clipboardItems: filteredItems });
                sendResponse({ success: true });
                break;
                
            case 'updateSettings':
                const { settings: newSettings } = request;
                await browser.storage.local.set({ settings: newSettings });
                sendResponse({ success: true });
                break;
                
            case 'checkTranslationLimit':
                const limitResult = await checkTranslationLimit();
                sendResponse(limitResult);
                break;
                
            default:
                sendResponse({ success: false, error: 'Unknown action' });
        }
    } catch (error) {
        console.error('Error handling message:', error);
        sendResponse({ success: false, error: error.message });
    }
    
    return true; // Keep message channel open for async response
});

// Check translation limit
async function checkTranslationLimit() {
    try {
        const { isPro, translationsThisMonth } = await browser.storage.local.get(['isPro', 'translationsThisMonth']);
        
        if (isPro) {
            return { canTranslate: true, limit: Infinity, used: 0 };
        }
        
        const now = new Date();
        const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        
        if (!translationsThisMonth || translationsThisMonth.month !== currentMonth) {
            await browser.storage.local.set({
                translationsThisMonth: {
                    month: currentMonth,
                    count: 0
                }
            });
            return { canTranslate: true, limit: EXTPAY_CONFIG.limits.free.translationsPerDay, used: 0 };
        }
        
        const canTranslate = translationsThisMonth.count < EXTPAY_CONFIG.limits.free.translationsPerDay;
        return {
            canTranslate,
            limit: EXTPAY_CONFIG.limits.free.translationsPerDay,
            used: translationsThisMonth.count
        };
    } catch (error) {
        console.error('Error checking translation limit:', error);
        return { canTranslate: false, limit: 0, used: 0 };
    }
}

// Translate text using proxy server
async function translateText(text, targetLang) {
    try {
        // Check translation limit first
        const limitCheck = await checkTranslationLimit();
        if (!limitCheck.canTranslate) {
            throw new Error('Translation limit reached for free users');
        }
        
        const TRANSLATE_PROXY_URL = 'https://clipsmart-translation-proxy.vercel.app/translate';
        
        const response = await fetch(TRANSLATE_PROXY_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Extension-Id': 'nbpndheaoecmgnlmfpleeahoicpcbppj'
            },
            body: JSON.stringify({
                text,
                targetLang,
                sourceLang: 'auto'
            })
        });
        
        if (!response.ok) {
            throw new Error(`Translation failed: ${response.status}`);
        }
        
        const result = await response.json();
        
        // Update translation count
        const { translationsThisMonth } = await browser.storage.local.get('translationsThisMonth');
        const now = new Date();
        const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        
        if (!translationsThisMonth || translationsThisMonth.month !== currentMonth) {
            await browser.storage.local.set({
                translationsThisMonth: {
                    month: currentMonth,
                    count: 1
                }
            });
        } else {
            await browser.storage.local.set({
                translationsThisMonth: {
                    month: currentMonth,
                    count: translationsThisMonth.count + 1
                }
            });
        }
        
        return result.translation;
    } catch (error) {
        console.error('Translation error:', error);
        throw error;
    }
}

// Handle context menu clicks
browser.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId === 'save-to-clipsmart') {
        try {
            const selectedText = info.selectionText;
            if (selectedText) {
                await browser.runtime.sendMessage({
                    action: 'saveClipboardItem',
                    text: selectedText,
                    source: tab.url || 'context-menu',
                    timestamp: Date.now()
                });
                
                // Show notification
                browser.notifications.create({
                    type: 'basic',
                    iconUrl: 'assets/icon-48.png',
                    title: 'ClipSmart',
                    message: 'Text saved to clipboard history'
                });
            }
        } catch (error) {
            console.error('Error saving text from context menu:', error);
        }
    }
});

console.log('🚀 ClipSmart Firefox background script loaded');
