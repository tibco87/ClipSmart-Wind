// ClipSmart Popup Script for Firefox
// ExtensionPay is loaded as a global function

class ClipSmart {
    constructor() {
        this.clipboardItems = [];
        this.filteredItems = [];
        this.currentTab = 'recent';
        this.searchQuery = '';
        this.freeItemLimit = 20;
        this.freeTranslationLimit = 5; // 5 prekladov mesačne pre free verziu
        this.translationsUsed = 0;
        this.isPro = false;
        this.defaultTransLangs = ['en', 'de', 'fr'];
        this.tags = new Set();
        this.translationLimit = 5; // 5 prekladov mesačne pre free verziu
        this.availableLanguages = ['en', 'de', 'fr', 'es', 'it', 'pt', 'pl', 'nl', 'da', 'sv', 'cs', 'sk', 'hu', 'ru', 'uk', 'ar', 'tr', 'zh', 'ja', 'id', 'vi', 'ko', 'hi', 'bn'];
        this.sortOrder = 'newest'; // Predvolené zoradenie
        this.locale = 'en';
        this.messages = {};
        this.extpay = null;
        
        this.init();
    }

    async init() {
        await this.loadData();
        await this.detectAndSetLocale();
        await this.loadMessages();
        await this.initializeExtPay();
        await this.checkTranslationLimit(); // Načítanie aktuálneho stavu mesačných prekladov
        this.setupEventListeners();
        this.applyTheme();
        this.renderContent();
        this.updateItemCount();
        this.updateUIText(); // Presunuté sem po načítaní všetkých dát
        this.updatePremiumModeCheckbox();
        
        // Kontrola jsPDF načítania
        if (typeof window.jspdf === 'undefined') {
            console.warn('jsPDF library not loaded - PDF export will not work');
            console.log('Available window properties:', Object.keys(window).filter(key => key.includes('pdf') || key.includes('PDF')));
        } else {
            console.log('jsPDF library loaded successfully');
        }
    }

    async initializeExtPay() {
        // Wait for ExtensionPay to load
        let retries = 0;
        while (!window.ExtPay && retries < 10) {
            await new Promise(resolve => setTimeout(resolve, 100));
            retries++;
        }
        
        if (!window.ExtPay) {
            console.error('❌ ExtensionPay failed to load after 10 retries');
            console.log('Available globals:', Object.keys(window).filter(key => key.includes('Ext')));
            return;
        }
        
        console.log('✅ ExtensionPay loaded successfully');
        
        try {
            // ExtensionPay is available globally
            // Use the production Extension ID from Chrome Web Store
            const extensionPayId = window.EXTPAY_CONFIG?.extensionId || 'nbpndheaoecmgnlmfpleeahoicpcbppj';
            this.extpay = window.ExtPay(extensionPayId);
            console.log('✅ ExtensionPay initialized with ID:', extensionPayId);
            console.log('ℹ️ Using ExtensionPay dashboard ID, not Chrome generated ID');
            
            // Synchronize ExtensionPay data with our isPro status
            await this.syncExtensionPayData();
            
            const user = await this.extpay.getUser();
            console.log('✅ User data retrieved:', user);
            console.log('🔍 User subscriptions:', user.subscriptions);
            console.log('🔍 User subscription data:', {
                subscriptionAmount: user.subscriptionAmount,
                subscriptionInterval: user.subscriptionInterval,
                subscriptionCurrency: user.subscriptionCurrency,
                subscriptionStatus: user.subscriptionStatus,
                subscriptionPlan: user.subscriptionPlan,
                plan: user.plan,
                planId: user.planId,
                planNickname: user.planNickname
            });
            
            // Explicit individual logging to see exact values
            console.log('💰 subscriptionAmount:', user.subscriptionAmount, typeof user.subscriptionAmount);
            console.log('📅 subscriptionInterval:', user.subscriptionInterval, typeof user.subscriptionInterval);
            console.log('💱 subscriptionCurrency:', user.subscriptionCurrency, typeof user.subscriptionCurrency);
            console.log('🏷️ planNickname:', user.planNickname, typeof user.planNickname);
            console.log('💎 paid:', user.paid, typeof user.paid);
            
            // Log all user object keys to see what's available
            console.log('🔍 All user object keys:', Object.keys(user));
            console.log('🔍 All user object values:', Object.entries(user));
            
            this.isPro = user.paid;
            
            // Update UI based on pro status
            this.updatePremiumModeCheckbox();
            this.updateLimits();
            
        } catch (error) {
            console.error('❌ Error initializing ExtensionPay:', error);
            // Fallback to free mode
            this.isPro = false;
        }
    }

    async loadData() {
        try {
            const data = await browser.storage.local.get([
                'clipboardItems', 
                'settings', 
                'isPro', 
                'translationsUsed',
                'translationsThisMonth'
            ]);
            
            this.clipboardItems = data.clipboardItems || [];
            this.settings = data.settings || {
                theme: 'auto',
                language: 'en',
                autoDelete: 'never',
                translationLangs: this.defaultTransLangs
            };
            this.isPro = data.isPro || false;
            this.translationsUsed = data.translationsUsed || 0;
            
            // Load translation count
            if (data.translationsThisMonth) {
                const now = new Date();
                const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
                
                if (data.translationsThisMonth.month === currentMonth) {
                    this.translationsUsed = data.translationsThisMonth.count || 0;
                } else {
                    // Reset for new month
                    this.translationsUsed = 0;
                    await browser.storage.local.set({
                        translationsThisMonth: {
                            month: currentMonth,
                            count: 0
                        },
                        translationsUsed: 0
                    });
                }
            }
            
            // Extract tags from items
            this.tags = new Set();
            this.clipboardItems.forEach(item => {
                if (item.tags && Array.isArray(item.tags)) {
                    item.tags.forEach(tag => this.tags.add(tag));
                }
            });
            
            console.log('✅ Data loaded successfully');
            console.log('📊 Clipboard items:', this.clipboardItems.length);
            console.log('🏷️ Tags:', Array.from(this.tags));
            console.log('💎 Pro status:', this.isPro);
            
        } catch (error) {
            console.error('❌ Error loading data:', error);
        }
    }

    async detectAndSetLocale() {
        try {
            // Try to get locale from browser
            const browserLocale = navigator.language || navigator.userLanguage || 'en';
            this.locale = browserLocale.split('-')[0];
            
            // Check if we have messages for this locale
            const availableLocales = ['en', 'de', 'fr', 'es', 'it', 'pt', 'pl', 'nl', 'da', 'sv', 'cs', 'sk', 'hu', 'ru', 'uk', 'ar', 'tr', 'zh', 'ja', 'id', 'vi', 'ko', 'hi', 'bn'];
            
            if (!availableLocales.includes(this.locale)) {
                this.locale = 'en'; // Fallback to English
            }
            
            console.log('🌍 Detected locale:', this.locale);
            
        } catch (error) {
            console.error('❌ Error detecting locale:', error);
            this.locale = 'en';
        }
    }

    async loadMessages() {
        try {
            const response = await fetch(browser.runtime.getURL(`_locales/${this.locale}/messages.json`));
            this.messages = await response.json();
            console.log('✅ Messages loaded for locale:', this.locale);
        } catch (error) {
            console.error('❌ Error loading messages for locale:', this.locale, error);
            // Fallback to English
            try {
                const response = await fetch(browser.runtime.getURL('_locales/en/messages.json'));
                this.messages = await response.json();
                this.locale = 'en';
                console.log('✅ Fallback to English messages');
            } catch (fallbackError) {
                console.error('❌ Failed to load fallback messages:', fallbackError);
                this.messages = {};
            }
        }
    }

    async checkTranslationLimit() {
        try {
            const response = await browser.runtime.sendMessage({ action: 'checkTranslationLimit' });
            if (response && response.success !== undefined) {
                this.translationLimit = response.limit;
                this.translationsUsed = response.used;
                console.log('✅ Translation limit checked:', response);
            }
        } catch (error) {
            console.error('❌ Error checking translation limit:', error);
        }
    }

    // ... rest of the class methods would continue here
    // For brevity, I'm showing the key differences above
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ClipSmart();
});
